extends RefCounted

const DATA := [
	{"role": "ASSASSIN", "speed": 205.0, "cooldown": 0.14, "cost": 9.0, "range": 78.0, "damage": 34, "shot_speed": 0.0, "radius": 0.0, "description": "Normal HP. Close the gap and land three rapid flame slashes for lethal burst."},
	{"role": "CONTROLLER", "speed": 145.0, "cooldown": 0.65, "cost": 16.0, "range": 340.0, "damage": 9, "shot_speed": 330.0, "radius": 10.0, "description": "Fan out three water shots. Impacts leave spreading flood zones that deny ground."},
	{"role": "FROST SUPPORT", "speed": 155.0, "cooldown": 0.48, "cost": 12.0, "range": 440.0, "damage": 17, "shot_speed": 420.0, "radius": 8.0, "description": "Ice shards briefly slow enemies by 18%. Keep moving and control their approach."},
	{"role": "MARKSMAN", "speed": 150.0, "cooldown": 0.82, "cost": 20.0, "range": 780.0, "damage": 29, "shot_speed": 850.0, "radius": 5.0, "description": "Fast, narrow lightning shots reach across the arena. Aim carefully and keep your distance."},
	{"role": "COMBO SKIRMISHER", "speed": 180.0, "cooldown": 0.34, "cost": 13.0, "range": 410.0, "damage": 15, "shot_speed": 530.0, "radius": 6.0, "description": "Chain long/narrow, medium/wide, then short/wide gusts. Each attack dashes; the finisher knocks back."}
]

static func get_profile(element: int) -> Dictionary:
	return DATA[clampi(element, 0, DATA.size() - 1)]
